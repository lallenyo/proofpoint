"use client";

import { Nav, PageWrapper } from "@/components/Nav";

// TODO: Port cs-roi-generator.jsx into src/components/CsRoiGenerator.tsx
// Change: fetch("https://api.anthropic.com/...") → fetch("/api/anthropic", ...)
// import CsRoiGenerator from "@/components/CsRoiGenerator";

export default function RoiCalculatorPage() {
  return (
    <>
      <Nav />
      <PageWrapper>
        <div style={{ maxWidth: 900, margin: "0 auto", padding: "60px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>💰</div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, marginBottom: 12 }}>CS ROI Report</h1>
          <p style={{ color: "#64748b", fontSize: 15 }}>
            Port <code style={{ background: "#0f172a", padding: "2px 6px", borderRadius: 4, color: "#10b981" }}>cs-roi-generator.jsx</code> into this page.
          </p>
        </div>
      </PageWrapper>
    </>
  );
}
