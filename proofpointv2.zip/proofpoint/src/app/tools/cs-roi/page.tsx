"use client";

import { Nav, PageWrapper } from "@/components/Nav";

// TODO: Port cs-program-roi-calculator.jsx into src/components/CsProgramRoi.tsx
// Change: fetch("https://api.anthropic.com/...") → fetch("/api/anthropic", ...)
// import CsProgramRoi from "@/components/CsProgramRoi";

export default function CsRoiPage() {
  return (
    <>
      <Nav />
      <PageWrapper>
        <div style={{ maxWidth: 900, margin: "0 auto", padding: "60px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📊</div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, marginBottom: 12 }}>CS Program ROI Calculator</h1>
          <p style={{ color: "#64748b", fontSize: 15 }}>
            Port <code style={{ background: "#0f172a", padding: "2px 6px", borderRadius: 4, color: "#10b981" }}>cs-program-roi-calculator.jsx</code> into this page.
          </p>
        </div>
      </PageWrapper>
    </>
  );
}
