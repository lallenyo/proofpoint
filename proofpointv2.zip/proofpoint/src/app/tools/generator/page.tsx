"use client";

import { Nav, PageWrapper } from "@/components/Nav";

/**
 * This page wraps the ProofpointGenerator component.
 *
 * HOW TO ADD YOUR JSX:
 * 1. Copy the contents of proofpoint-generator.jsx into /src/components/ProofpointGenerator.tsx
 * 2. Make these two changes to the component:
 *
 *    a) Replace the direct Anthropic fetch:
 *       FROM: fetch("https://api.anthropic.com/v1/messages", { headers: { "x-api-key": "..." } })
 *       TO:   fetch("/api/anthropic", { method: "POST", ... })
 *
 *    b) Replace the HubSpot fetch block in HubSpotPanel with:
 *       const res = await fetch("/api/hubspot", {
 *         method: "POST",
 *         headers: { "Content-Type": "application/json" },
 *         body: JSON.stringify({ token, companyName: query, saveToken: true })
 *       });
 *       const filled = await res.json();
 *
 *    c) After generating a report, save it:
 *       await fetch("/api/reports", {
 *         method: "POST",
 *         headers: { "Content-Type": "application/json" },
 *         body: JSON.stringify({ companyName: form.companyName, format, form, report, industry, mrr: form.mrr })
 *       });
 *
 * 3. Uncomment the import below and remove the placeholder div.
 */

// import ProofpointGenerator from "@/components/ProofpointGenerator";

export default function GeneratorPage() {
  return (
    <>
      <Nav />
      <PageWrapper>
        {/* TODO: Replace with <ProofpointGenerator /> once component is ported */}
        <div style={{ maxWidth: 900, margin: "0 auto", padding: "60px 24px", textAlign: "center" }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>📄</div>
          <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, marginBottom: 12 }}>Report Generator</h1>
          <p style={{ color: "#64748b", fontSize: 15, marginBottom: 24 }}>
            Port <code style={{ background: "#0f172a", padding: "2px 6px", borderRadius: 4, color: "#10b981" }}>proofpoint-generator.jsx</code> into{" "}
            <code style={{ background: "#0f172a", padding: "2px 6px", borderRadius: 4, color: "#10b981" }}>src/components/ProofpointGenerator.tsx</code>
          </p>
          <p style={{ color: "#475569", fontSize: 13 }}>See the comments in this file for the 3 changes needed.</p>
        </div>
      </PageWrapper>
    </>
  );
}
