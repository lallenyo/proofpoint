# Proofpoint — CS Intelligence Platform

AI-powered customer success reports, ROI analysis, and next-action recommendations.

## Stack

- **Next.js 14** (App Router)
- **Clerk** — Authentication
- **Supabase** — Database + Row Level Security
- **Anthropic Claude** — AI generation (server-proxied)
- **Vercel** — Deployment

---

## Setup (First Time)

### 1. Install dependencies

```bash
npm install
```

### 2. Create your `.env.local`

```bash
cp .env.example .env.local
```

Then fill in all values — see `.env.example` for what's needed.

**Services to set up:**
- [Anthropic Console](https://console.anthropic.com) → API Keys
- [Clerk Dashboard](https://dashboard.clerk.com) → Create app → copy keys
- [Supabase](https://app.supabase.com) → New project → Settings → API

### 3. Set up the database

In **Supabase Dashboard → SQL Editor**, run the contents of `supabase-schema.sql`.

This creates:
- `reports` table with row-level security
- `user_integrations` table for stored HubSpot tokens
- `waitlist` table for landing page signups

### 4. Run locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## Porting Your Existing JSX Components

Each tool page has a placeholder and instructions. To activate a tool:

1. Copy your `.jsx` file into `src/components/`
2. Rename to `.tsx` and add types if needed
3. Make this change to every `fetch` call:

```typescript
// BEFORE (exposes API key)
fetch("https://api.anthropic.com/v1/messages", {
  headers: { "x-api-key": "sk-ant-..." },
  body: JSON.stringify({ model: "...", messages: [...] })
})

// AFTER (secure — goes through your server)
fetch("/api/anthropic", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ system: "...", messages: [...] })
})
```

4. For HubSpot, change the fetch target in `HubSpotPanel`:

```typescript
// BEFORE (5 direct calls, token exposed)
fetch("https://api.hubapi.com/crm/v3/objects/companies/search", ...)

// AFTER (one proxied call, token stays server-side)
fetch("/api/hubspot", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ token, companyName: query, saveToken: true })
})
```

5. Add a save-report call after generation:

```typescript
await fetch("/api/reports", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    companyName: form.companyName,
    format,        // 'executive', 'qbr', etc.
    form,          // all form fields
    report,        // the generated markdown
    industry,
    mrr: form.mrr
  })
});
```

6. Uncomment the import in the tool's `page.tsx`

---

## Deploy to Vercel

```bash
npm install -g vercel
vercel

# Add environment variables
vercel env add ANTHROPIC_API_KEY
vercel env add NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY
vercel env add CLERK_SECRET_KEY
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY

# Deploy to production
vercel --prod
```

---

## API Routes

| Route | Method | Description |
|-------|--------|-------------|
| `/api/anthropic` | POST | Secure Claude proxy (auth required) |
| `/api/hubspot` | POST | HubSpot company search proxy |
| `/api/hubspot` | GET | Check if HubSpot token is stored |
| `/api/reports` | GET | List user's saved reports |
| `/api/reports` | POST | Save a new report |
| `/api/reports/[id]` | GET | Fetch a single report |
| `/api/reports/[id]` | DELETE | Delete a report |

---

## Project Structure

```
src/
├── app/
│   ├── layout.tsx          ← Clerk provider
│   ├── page.tsx            ← Landing page
│   ├── middleware.ts        ← Auth guard
│   ├── dashboard/          ← Main dashboard
│   ├── tools/
│   │   ├── generator/      ← Report generator
│   │   ├── next-action/    ← Next action analyzer
│   │   ├── roi-calculator/ ← CS ROI report
│   │   └── cs-roi/         ← CS program ROI
│   ├── reports/[id]/       ← Saved report viewer
│   ├── sign-in/            ← Clerk sign-in
│   ├── sign-up/            ← Clerk sign-up
│   └── api/
│       ├── anthropic/      ← AI proxy
│       ├── hubspot/        ← HubSpot proxy
│       └── reports/        ← Report CRUD
├── components/
│   └── Nav.tsx             ← Shared navigation
└── lib/
    └── supabase.ts         ← DB client + types
```
